//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file DetectorConstruction.cc
/// \brief Implementation of the DetectorConstruction class

#include "DetectorConstruction.hh"
#include "ElectricFieldSetup.hh"
#include "SensitiveDetector.hh"

#include "G4SDStructure.hh"
#include "G4SDManager.hh"

#include "G4GenericTrap.hh"
#include "G4AutoDelete.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4ExtrudedSolid.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trap.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"
#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"


//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction::DetectorConstruction()
	: G4VUserDetectorConstruction()
	//fLogicElectrode(0), fLogicElectrodeB(0)
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction::~DetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* DetectorConstruction::Construct()
{
	// Get nist material manager
	G4NistManager* nist = G4NistManager::Instance();

	//G4double fChamber_SizeXY = 1.5 * cm;
	//G4double fChamber_SizeZ = 5. * cm;

	G4double fChamber_SizeX = 3 * cm;
	G4double fChamber_SizeY = 1.5 * cm;
	G4double fChamber_SizeZ = 15. * cm;

	G4double fPipeForElectron_SizeX = 12.0 * mm;
	G4double fPipeForElectron_SizeY = 12.0 * mm;
	G4double fPipeForElectron_SizeZ = 149.5 * mm;

	G4double fBeamCheck_SizeX = 4.0 * mm;
	G4double fBeamCheck_SizeY = 2.0 * mm;
	G4double fBeamCheck_SizeZ = 0.1 * mm;

	G4double fElectrode_SizeXZ = 1 * cm;
	G4double fElectrode_SizeY = 0.005 * cm;

	G4Material* fAir = nist->FindOrBuildMaterial("G4_AIR");
	G4Material* fCopper = nist->FindOrBuildMaterial("G4_Cu");
	G4Material* fVacuum = nist->FindOrBuildMaterial("G4_Galactic");
	G4Material* fStainless = nist->FindOrBuildMaterial("G4_STAINLESS-STEEL");
	G4Material* fXenon = nist->FindOrBuildMaterial("G4_Xe");


	//G4double temperature = CLHEP::STP_Temperature;
	G4double temperature = 300 * kelvin;

    //1 --> 1E-3 Pa 일 때의 밀도
	//G4double pressure = 1e-0 * hep_pascal;
	//G4double Xe_density = 5.252e-5 * mg / cm3;

	//G4double pressure = 1e-1 * hep_pascal;
	//double Xe_density = 5.252e-6 * mg / cm3;

	//G4double pressure = 1e-2 * hep_pascal;
	//double Xe_density = 5.252e-7 * mg / cm3;

	G4double pressure = 1e-3 * hep_pascal;
	double Xe_density = 5.252e-8 * mg / cm3;

	G4Material* my_gas = new G4Material("LowP_Xe_Gas", Xe_density, 1,
		kStateGas, temperature, pressure);
	my_gas->AddMaterial(fXenon, 1);
	G4Material* fChamber_gas = my_gas;

	// Option to switch on/off checking of volumes overlaps
	G4bool checkOverlaps = true;

	//     
	// World
	//
	G4double fWorld_SizeXY = 2 * fChamber_SizeX;
	G4double fWorld_SizeZ = 2 * fChamber_SizeZ;

	G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");

	G4Box* fsolidWorld =
		new G4Box("World",                       //its name
			fWorld_SizeXY,
			fWorld_SizeXY,
			fWorld_SizeZ);     //its size

	G4LogicalVolume* flogicWorld =
		new G4LogicalVolume(
			fsolidWorld,          //its solid
			fVacuum,			  //world_mat
			"World");             //its name

	G4VPhysicalVolume* fphysWorld =
		new G4PVPlacement(0,                     //no rotation
			G4ThreeVector(),       //at (0,0,0)
			flogicWorld,            //its logical volume
			"World",               //its name
			0,                     //its mother  volume
			false,                 //no boolean operation
			0,                     //copy number
			checkOverlaps);        //overlaps checking

	G4Box* fSolidEnv =
		new G4Box("Envelope",
			0.8 * fWorld_SizeXY,
			0.8 * fWorld_SizeXY,
			0.8 * fWorld_SizeZ);

	G4LogicalVolume* fLogicEnv =
		new G4LogicalVolume(fSolidEnv,
			fVacuum,			   // its material
			//fAir,			       // its material
			"Envelope");

	G4VPhysicalVolume* fPhysEnv =
		new G4PVPlacement(0,
			G4ThreeVector(),
			"Envelope",
			fLogicEnv,
			fphysWorld,
			false,
			0,
			checkOverlaps);

	G4Box* fSolidChamber =
		new G4Box("Chamber",
			fChamber_SizeX,
			fChamber_SizeY,
			fChamber_SizeZ);

	G4LogicalVolume* fLogicChamber =
		new G4LogicalVolume(fSolidChamber,
			fChamber_gas,
			"Chamber");

	G4VPhysicalVolume* PhysiChamber =
		new G4PVPlacement(0,
			G4ThreeVector(),
			"Chamber",
			fLogicChamber,
			fPhysEnv,
			false,
			0,
			checkOverlaps);

	//fScoringVolume = fLogicElectrode;

	// Sensitive Detectors
	G4SDManager* SDman = G4SDManager::GetSDMpointer();

	SensitiveDetector* SD_A = new SensitiveDetector("ElectrodeSD_A");
	SDman->AddNewDetector(SD_A);

	SensitiveDetector* SD_B = new SensitiveDetector("ElectrodeSD_B");
	SDman->AddNewDetector(SD_B);

    // photon beam 에너지, 분포 확인하기 위한 SD, photon beam 진행방향에 수직인 얇은 판
	SensitiveDetector* SD_BeamCheck = new SensitiveDetector("BeamCheckSD");
	SDman->AddNewDetector(SD_BeamCheck);

    // 생성된 photo-electron 값들을 추출하기 위한 SD
	SensitiveDetector* SD_PipeForElectron = new SensitiveDetector("SDForElectron");
	SDman->AddNewDetector(SD_PipeForElectron);

	std::vector<G4TwoVector> verticesA = { {10,10}, {-10,-10}, {-10,10} };
	std::vector<G4TwoVector> verticesB = { {10,10}, {-10,-10}, { 10,10} };

	G4double Electrode_thickness = 1 * mm;

	G4ExtrudedSolid* fSolidElectrodeA = new G4ExtrudedSolid(
		"ElectrodeA",
		{ {20,180}, {-20,-20}, {-20,180} },
		{ {0,{0,0},1}, {1,{0,0},1} });
	G4ExtrudedSolid* fSolidElectrodeB = new G4ExtrudedSolid(
		"ElectrodeB",
		{ {20,180}, {-20,-20}, {20,-20} },
		{ {0,{0,0},1}, {1,{0,0},1} });

	G4LogicalVolume* fLogicElectrodeA =
		new G4LogicalVolume(fSolidElectrodeA,
			//fCopper,
			fVacuum,
			"ElectrodeA",
			0,
			SD_A);

	G4RotationMatrix RotMatA = G4RotationMatrix();
	RotMatA.rotateX(90 * deg);
	RotMatA.rotateY(0);
	RotMatA.rotateZ(0);
	G4ThreeVector Pos_ElecA = G4ThreeVector(0, -(fChamber_SizeY + fElectrode_SizeY) + 0.05 * mm, -(fChamber_SizeZ / 2));
	G4Transform3D TransformA = G4Transform3D(RotMatA, Pos_ElecA);

	//G4VPhysicalVolume* PhysiElectrodeA =
	new G4PVPlacement(TransformA,
		"ElectrodeA",
		fLogicElectrodeA,
		fPhysEnv,
		false,
		3,
		checkOverlaps);

	G4LogicalVolume* fLogicElectrodeB =
		new G4LogicalVolume(fSolidElectrodeB,
			//fCopper,
			fVacuum,
			"ElectrodeB",
			0,
			SD_B);

	G4RotationMatrix RotMatB = G4RotationMatrix();
	RotMatB.rotateX(90 * deg);
	RotMatB.rotateY(0);
	RotMatB.rotateZ(0);
	G4ThreeVector Pos_ElecB = G4ThreeVector(0, -(fChamber_SizeY + fElectrode_SizeY) + 0.05 * mm, -(fChamber_SizeZ / 2));
	G4Transform3D TransformB = G4Transform3D(RotMatB, Pos_ElecB);

	//G4VPhysicalVolume* PhysiElectrodeB =
	new G4PVPlacement(TransformB,
		"ElectrodeB",
		fLogicElectrodeB,
		fPhysEnv,
		false,
		4,
		checkOverlaps);


	G4Box* fSolidSDforElec =
		new G4Box("SDforElec",
			fPipeForElectron_SizeX,
			fPipeForElectron_SizeY,
			fPipeForElectron_SizeZ);

	G4LogicalVolume* fLogicSDforElec =
		new G4LogicalVolume(fSolidSDforElec,
			fChamber_gas,
			"SDforElec",
			0, SD_PipeForElectron);


	//G4VPhysicalVolume* PhysiChamber = 
	new G4PVPlacement(0,
		G4ThreeVector(0, 0, 0),
		"Pipe",
		fLogicSDforElec,
		PhysiChamber,
		false,
		11,
		checkOverlaps);


	G4Box* fSolidBeamCheck =
		new G4Box("BeamCheck",
			fBeamCheck_SizeX,
			fBeamCheck_SizeY,
			fBeamCheck_SizeZ);

	G4LogicalVolume* fLogicBeamCheck =
		new G4LogicalVolume(fSolidBeamCheck,
			//fVacuum,
			fChamber_gas,
			"BeamCheck",
			0, SD_BeamCheck);


	//G4VPhysicalVolume* PhysiChamber = 
	new G4PVPlacement(0,
		//G4ThreeVector(0, -13 * mm, -49.9 * mm),
		G4ThreeVector(0, -5 * mm, -fPipeForElectron_SizeZ - 0.2 * mm),
		"BeamCheck",
		fLogicBeamCheck,
		PhysiChamber,
		false,
		0,
		checkOverlaps);

	// set region for SetCuts
	G4String regName[] = { "chamber", "electrode", "envelope", "beampipe", "beamcheck" };

	ChamberRegion = new G4Region(regName[0]);
	fLogicChamber->SetRegion(ChamberRegion);
	ChamberRegion->AddRootLogicalVolume(fLogicChamber);

	ElectrodeRegion = new G4Region(regName[1]);
	fLogicElectrodeA->SetRegion(ElectrodeRegion);
	ElectrodeRegion->AddRootLogicalVolume(fLogicElectrodeA);
	fLogicElectrodeB->SetRegion(ElectrodeRegion);
	ElectrodeRegion->AddRootLogicalVolume(fLogicElectrodeB);

	EnvelopeRegion = new G4Region(regName[2]);
	fLogicEnv->SetRegion(EnvelopeRegion);
	EnvelopeRegion->AddRootLogicalVolume(fLogicEnv);

	PipeRegion = new G4Region(regName[3]);
	fLogicSDforElec->SetRegion(PipeRegion);
	PipeRegion->AddRootLogicalVolume(fLogicSDforElec);

	BeamCheckRegion = new G4Region(regName[4]);
	fLogicBeamCheck->SetRegion(BeamCheckRegion);
	BeamCheckRegion->AddRootLogicalVolume(fLogicBeamCheck);

	G4cout << *(G4Material::GetMaterialTable()) << G4endl;
	return fphysWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void DetectorConstruction::ConstructSDandField()
{
	if (!fEmFieldSetup.Get()) {
		ElectricFieldSetup* fieldSetup = new ElectricFieldSetup();
		G4AutoDelete::Register(fieldSetup); //Kernel will delete the messenger
		fEmFieldSetup.Put(fieldSetup);
	}

}
